
#define NAMESPACE HIDUSB
#include "hid.c"
